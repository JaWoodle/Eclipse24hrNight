using DMT;
using HarmonyLib;
using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

class Khaine_AIDirectorBloodMoonComponent_Patch
{
    public class Khaine_AIDirectorWanderingHordeComponent_Logger
    {
        public static bool blDisplayLog = false;

        public static void Log(String strMessage)
        {
            if (blDisplayLog)
                UnityEngine.Debug.Log(strMessage);
        }
    }
	
    public class Init : IHarmony
    {
        public void Start()
        {
			Debug.Log(" Loading Patch: " + this.GetType().ToString());
			var harmony = new Harmony("Khaine.BloodmoonComponent.Patch");
			harmony.PatchAll();
        }
    }

	[HarmonyPatch(typeof(AIDirectorBloodMoonComponent))]
	[HarmonyPatch("ComputeDawnAndDuskTimes")]
	public class Khaine_BloodmoonComponentPatch
    {
		public static void Prefix(ref int ___duskHour, ref int ___dawnHour)
		{
			___duskHour = 22;
			___dawnHour = 4;
		}
	}
}